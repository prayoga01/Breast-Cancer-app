// PredictionController.java
package com.example.breast_cancer_rest.controller;

import com.example.breast_cancer_rest.model.InputData;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/prediction")
@CrossOrigin(origins = "*")
public class PredictionController {

    @PostMapping("/predict")
    public ResponseEntity<Map<String, Object>> predict(@RequestBody InputData inputData) {
        try {
            // Validate input data
            if (inputData == null) {
                return ResponseEntity.badRequest()
                    .body(createErrorResponse("Input data is required"));
            }

            // Validate required fields
            if (inputData.getBenjolanDiPayudara() == null || inputData.getBenjolanDiPayudara().isEmpty()) {
                return ResponseEntity.badRequest()
                    .body(createErrorResponse("Benjolan di Payudara is required"));
            }

            // Convert input to format suitable for ML model
            String[] features = convertInputToFeatures(inputData);
            
            // Call your ML prediction service here
            String prediction = performPrediction(features);
            
            // Create response
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("prediction", prediction);
            response.put("confidence", calculateConfidence(features));
            response.put("timestamp", System.currentTimeMillis());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            // Log the error
            System.err.println("Error in prediction: " + e.getMessage());
            e.printStackTrace();
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(createErrorResponse("Internal server error: " + e.getMessage()));
        }
    }

    private String[] convertInputToFeatures(InputData inputData) {
        return new String[] {
            inputData.getFaktorRisiko(),
            inputData.getBenjolanDiPayudara(),
            inputData.getKecepatanTumbuh(),
            inputData.getNippleDischarge(),
            inputData.getRetraksiPutingSusu(),
            inputData.getKrusta(),
            inputData.getDimpling(),
            inputData.getPeauDOrange(),
            inputData.getUlserasi(),
            inputData.getVenektasi(),
            inputData.getBenjolanKetiak(),
            inputData.getEdemaLengan(),
            inputData.getNyeriTulang(),
            inputData.getSesak()
        };
    }

    private String performPrediction(String[] features) {
        // This is where you would call your ML model
        // For now, returning a mock prediction
        
        // Count positive symptoms
        int positiveCount = 0;
        for (String feature : features) {
            if ("ya".equals(feature)) {
                positiveCount++;
            }
        }
        
        // Simple logic for demo (replace with actual ML model)
        if (positiveCount >= 3) {
            return "breast cancer";
        } else {
            return "non breast cancer";
        }
    }

    private double calculateConfidence(String[] features) {
        // Mock confidence calculation
        return Math.random() * 0.3 + 0.7; // Random between 0.7 and 1.0
    }

    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> error = new HashMap<>();
        error.put("status", "error");
        error.put("message", message);
        error.put("timestamp", System.currentTimeMillis());
        return error;
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "healthy");
        response.put("service", "breast-cancer-prediction");
        return ResponseEntity.ok(response);
    }
}